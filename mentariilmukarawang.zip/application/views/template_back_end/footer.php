            <footer class="footer t-a-c">
                © 2019 TitikKoma.Dev - Yayasan Mentari Ilmu Karawang
            </footer>