
	<footer id="fh5co-footer" role="contentinfo" style="background-image: url(<?= base_url(); ?>assets/front_end_new/images/img_bg_4.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row copyright">
				<div class="col-md-12 text-center">
					<p>
						<small class="block">&copy; 2019 TitikKoma.Dev - Yayasan Mentari Ilmu Karawang. All Rights Reserved.</small> 
					</p>
				</div>
			</div>

		</div>
	</footer>