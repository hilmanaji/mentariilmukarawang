<div class="container container-fluid">
    <div class="container">
        <div class="row mt-5">
            Ini list dan Link sekolah mentil
        </div>
    </div>    
</div>