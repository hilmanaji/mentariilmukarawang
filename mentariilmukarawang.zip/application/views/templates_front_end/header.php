<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>YAYASAN MENTARI ILMU</title>

  <!-- Bootstrap core JavaScript -->
  <script src="<?= base_url(); ?>assets/front_end/vendor/jquery/jquery.min.js"></script>
  <script src="<?= base_url(); ?>assets/front_end/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Bootstrap core CSS -->
  <link href="<?= base_url(); ?>assets/front_end/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Custom styles for this template -->
  <link href="<?= base_url(); ?>assets/front_end/css/modern-business.css" rel="stylesheet">
  <link href="<?= base_url(); ?>assets/front_end/css/style.css" rel="stylesheet">
  
</head>