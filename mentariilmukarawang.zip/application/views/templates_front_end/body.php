<!DOCTYPE html>
<html lang="en">

<?php echo $_head; ?>

<body id="page-top">


        <!-- ===== Top-Navigation ===== -->
        <?php echo $_navbar; ?>
        <!-- ===== Top-Navigation-End ===== -->

        <!-- Page Content -->
        <?php echo $_content; ?>
        <!-- Page Content - End -->

        <!-- Footer -->
        <?php echo $_footer; ?>
        <!-- Footer - End-->

</body>

</html>